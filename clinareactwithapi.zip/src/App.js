import './App.css';
import Login from './Components/Login';
import Loginpopup from './/Components/Loginpopup';
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Dashboard from './Components/Dashboard';
// import Navbar from './Components/Navbar';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
       
        <Routes>
          <Route exact path="/" element={<Dashboard />} />
          <Route path="/D" element={<Login />} />
          <Route path="/LP" element={<Loginpopup />} />
        </Routes>
      </BrowserRouter>

     
    </div>
  );
}

export default App;
