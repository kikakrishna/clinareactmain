import * as React from 'react';
import Button from '@mui/material/Button';
import Loginpopup from './Loginpopup';
import { Link } from "react-router-dom";

class Popup extends React.Component {
    render() {
        return (
            <div className='popup'>
                <div className='popup_inner'>
                    <Loginpopup />
                    {/* <h1>{this.props.text}</h1> */}
                    <Button onClick={this.props.closePopup}>Close</Button>
                </div>
            </div>
        );
    }
}



class Login extends React.Component {

    constructor() {
        super();
        this.state = {
            showPopup: false
        };
    }
    togglePopup() {
        console.log('fefef')
        this.setState({
            showPopup: !this.state.showPopup
        });
    }

    render() {
        return (
            <div>
                <nav>

                    {/* <Button onClick={this.togglePopup.bind(this)}>Login</Button>

                    {this.state.showPopup ?
                        <Popup
                            text='Close Me'
                            closePopup={this.togglePopup.bind(this)}
                        />
                        : null
                    } */}


                    <Link to="/LP"> <Button>Login</Button></Link>
                </nav>

            </div>
        )
    }
}

export default (Login);