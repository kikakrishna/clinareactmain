import * as React from 'react';
import Button from '@mui/material/Button';
import Login from './Login';





export default function Dashboard() {
    return (
        <div>
            <Login />
        </div>
    );

}
